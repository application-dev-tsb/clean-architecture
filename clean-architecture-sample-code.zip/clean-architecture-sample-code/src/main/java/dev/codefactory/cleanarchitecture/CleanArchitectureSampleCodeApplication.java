package dev.codefactory.cleanarchitecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanArchitectureSampleCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanArchitectureSampleCodeApplication.class, args);
	}

}
