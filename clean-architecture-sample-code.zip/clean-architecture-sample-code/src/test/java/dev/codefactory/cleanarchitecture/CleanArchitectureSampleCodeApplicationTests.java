package dev.codefactory.cleanarchitecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanArchitectureSampleCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
